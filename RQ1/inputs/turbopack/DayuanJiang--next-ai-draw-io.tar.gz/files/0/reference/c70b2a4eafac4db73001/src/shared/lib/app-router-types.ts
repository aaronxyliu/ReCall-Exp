/**
 * App Router types - Client-safe types for the Next.js App Router
 *
 * This file contains type definitions that can be safely imported
 * by both client-side and server-side code without circular dependencies.
 */

import type React from 'react'

export type LoadingModuleData =
  | [React.JSX.Element, React.ReactNode, React.ReactNode]
  | null

import type { VaryParamsIterable } from './segment-cache/vary-params-decoding'

/** viewport metadata node */
export type HeadData = React.ReactNode

/**
 * Cache node used in app-router / layout-router.
 */

export type CacheNode = {
  /**
   * When rsc is not null, it represents the RSC data for the
   * corresponding segment.
   *
   * `null` is a valid React Node but because segment data is always a
   * <LayoutRouter> component, we can use `null` to represent empty. When it is
   * null, it represents missing data, and rendering should suspend.
   */
  rsc: React.ReactNode

  /**
   * Represents a static version of the segment that can be shown immediately,
   * and may or may not contain dynamic holes. It's prefetched before a
   * navigation occurs.
   *
   * During rendering, we will choose whether to render `rsc` or `prefetchRsc`
   * with `useDeferredValue`. As with the `rsc` field, a value of `null` means
   * no value was provided. In this case, the LayoutRouter will go straight to
   * rendering the `rsc` value; if that one is also missing, it will suspend and
   * trigger a lazy fetch.
   */
  prefetchRsc: React.ReactNode

  prefetchHead: HeadData | null

  head: HeadData

  slots: Record<string, CacheNode> | null

  /**
   * A shared mutable ref that tracks whether this segment should be scrolled
   * to. All new segments created during a single navigation share the same
   * ref. When any segment's scroll handler fires, it sets `current` to
   * `false` so no other segment scrolls for the same navigation.
   *
   * `null` means this segment is not a scroll target (e.g., a reused shared
   * layout segment).
   */
  scrollRef: ScrollRef | null

  /**
   * Globally-unique identifier minted from a monotonic counter when the
   * CacheNode is freshly created. Surfaced to user code as a string via
   * `useRouter().bfcacheId` and intended to be used as a React `key` to
   * opt out of Activity-based state preservation on fresh navigations.
   *
   * Preserved when the CacheNode is reused (shared layouts, refresh,
   * search/hash-only navigations) or restored from the BFCache during a
   * back/forward navigation.
   */
  bfcacheId: number
}

/**
 * A mutable ref shared across all new segments created during a single
 * navigation. Used to ensure that only one segment scrolls per navigation.
 */
export type ScrollRef = { current: boolean }

export type DynamicParamTypes =
  | 'catchall'
  | 'catchall-intercepted-(..)(..)'
  | 'catchall-intercepted-(.)'
  | 'catchall-intercepted-(..)'
  | 'catchall-intercepted-(...)'
  | 'optional-catchall'
  | 'dynamic'
  | 'dynamic-intercepted-(..)(..)'
  | 'dynamic-intercepted-(.)'
  | 'dynamic-intercepted-(..)'
  | 'dynamic-intercepted-(...)'

export type DynamicParamTypesShort =
  | 'c'
  | 'ci(..)(..)'
  | 'ci(.)'
  | 'ci(..)'
  | 'ci(...)'
  | 'oc'
  | 'd'
  | 'di(..)(..)'
  | 'di(.)'
  | 'di(..)'
  | 'di(...)'

// The tuple form of a segment, used for dynamic route params
export type DynamicSegmentTuple = [
  // Param name
  paramName: string,
  // Param cache key (almost the same as the value, but arrays are
  // concatenated into strings)
  // TODO: We should change this to just be the value. Currently we convert
  // it back to a value when passing to useParams. It only needs to be
  // a string when converted to a a cache key, but that doesn't mean we
  // need to store it as that representation.
  paramCacheKey: string,
  // Dynamic param type
  dynamicParamType: DynamicParamTypesShort,
  // Static sibling segments at the same URL level. Used by the client
  // router to determine if a prefetch can be reused when navigating to
  // a static sibling of a dynamic route. For example, if the route is
  // /products/[id] and there's also /products/sale, then staticSiblings
  // would be ['sale']. null means the siblings are unknown (e.g. in
  // webpack dev mode).
  staticSiblings: readonly string[] | null,
]

export type Segment = string | DynamicSegmentTuple

/**
 * Router state
 */
export type FlightRouterState = [
  segment: Segment,
  parallelRoutes: { [parallelRouterKey: string]: FlightRouterState },
  refreshState?: CompressedRefreshState | null,
  /**
   * - "refetch" is used during a request to inform the server where rendering
   *   should start from.
   *
   * - "inside-shared-layout" is used during a prefetch request to inform the
   *   server that even if the segment matches, it should be treated as if it's
   *   within the "new" part of a navigation — inside the shared layout. If
   *   the segment doesn't match, then it has no effect, since it would be
   *   treated as new regardless. If it does match, though, the server does not
   *   need to render it, because the client already has it.
   *
   * - "metadata-only" instructs the server to skip rendering the segments and
   *   only send the head data.
   *
   *   A bit confusing, but that's because it has only one extremely narrow use
   *   case — during a non-PPR prefetch, the server uses it to find the first
   *   loading boundary beneath a shared layout.
   *
   *   TODO: We should rethink the protocol for dynamic requests. It might not
   *   make sense for the client to send a FlightRouterState, since this type is
   *   overloaded with concerns.
   */
  refresh?: 'refetch' | 'inside-shared-layout' | 'metadata-only' | null,
  /**
   * Bitmask of PrefetchHint flags. Encodes route structure metadata:
   * root layout, loading boundaries, instant configs, and prefetch strategy
   * hints. Only set when non-zero.
   */
  prefetchHints?: number,
]

/**
 * When rendering a parallel route, some of the parallel paths may not match
 * the current URL. In that case, the Next client has to render something,
 * so it will render whichever was the last route to match that slot. We use
 * this type to track when this has happened. It's a tuple of the original
 * URL that was used to fetch the segment, and the (possibly rewritten) search
 * query that was rendered by the server. The URL is needed when performing
 * a refresh of the segment, and the search query is needed for looking up
 * matching entries in the segment cache.
 */
export type CompressedRefreshState = [url: string, renderedSearch: string]

export const enum PrefetchHint {
  // NOTE: The 0b00001 bit was previously HasRuntimePrefetch (prefetch:
  // 'allow-runtime'). Partial Prefetching now implies runtime completeness
  // for every segment, so the bit was removed. Do not reuse it without
  // considering caches populated by older builds.

  // This segment or one of its descendants opts into Partial Prefetching, i.e.
  // uses the two-phase (Shell then Speculative) prefetch flow. Set when
  // `prefetch` is 'partial' or 'unstable_eager' (including the defaults
  // implied by the global `partialPrefetching` config). Propagates upward so
  // the root segment reflects the entire subtree.
  //
  // Partial Prefetching segments require RUNTIME COMPLETENESS: a prefetch
  // isn't considered done for such a segment until an entry at least as
  // complete as a runtime response exists. This does NOT mean the segment
  // lacks static data — the server emits static data unconditionally, and the
  // scheduler may attempt a static prefetch first (per
  // ShouldAttemptStaticPrefetch), issuing the runtime request only if the
  // static response's own `needsRuntimeRequest` signal says it would
  // return more.
  SubtreeHasPartialPrefetching = 0b00010,
  // This segment itself has a loading.tsx boundary.
  SegmentHasLoadingBoundary = 0b00100,
  // A descendant segment (but not this one) has a loading.tsx boundary.
  // Propagates upward so the root reflects the entire subtree.
  SubtreeHasLoadingBoundary = 0b01000,
  // This segment is at or above the application's root layout — the root layout
  // segment itself and all of its ancestors. A dynamic param in one of these
  // segments is a "root param".
  IsRootLayoutOrAbove = 0b10000,
  // This segment's response includes its parent's data inlined into it.
  // Set at build time by the segment size measurement pass.
  ParentInlinedIntoSelf = 0b100000,
  // This segment's data is inlined into one of its children — don't fetch
  // it separately. Set at build time by the segment size measurement pass.
  InlinedIntoChild = 0b1000000,
  // On a __PAGE__: this page's response includes the head (metadata/viewport)
  // at the end of its SegmentPrefetch[] array.
  HeadInlinedIntoSelf = 0b10000000,
  // On the root hint node: the head was NOT inlined into any page — fetch
  // it separately. Absence of this bit means the head is bundled into a page.
  HeadOutlined = 0b100000000,
  // The inlining hints in this tree may be stale because the tree was
  // generated before collectPrefetchHints ran (e.g. the initial RSC payload
  // for a fully static page at build time). When writing this tree into the
  // cache, the route entry should be immediately expired so it gets
  // re-fetched with correct hints. Only set during build-time prerendering,
  // never at runtime.
  InliningHintsStale = 0b1000000000,
  // This segment has prefetch = 'force-disabled'. The opt-out is passive
  // and applies to this segment only: it never INITIATES a prefetch — no
  // static data is emitted or fetched, and it's never the reason a runtime
  // prefetch spawns — but it may ride along in a runtime response issued on
  // another segment's behalf. Descendants prefetch normally.
  //
  // TODO: Also set as an internal fallback when the prefetch hints manifest
  // is unavailable (see #91407 mitigations), which only means "no static
  // prefetch data exists" — not a user opt-out. Split the fallback into its
  // own bit so the two intents can diverge.
  PrefetchDisabled = 0b10000000000,
  // NOTE: The 0b100000000000 bit was previously SubtreeHasRuntimePrefetch.
  // Partial Prefetching now implies runtime completeness for every segment
  // (see SubtreeHasPartialPrefetching), so the bit was removed. Do not reuse
  // it without considering caches populated by older builds.

  // This segment or one of its descendants prefetches "eagerly" — i.e. its
  // effective prefetch strategy is anything other than 'partial'. Used by
  // App Shells: a non-eager subtree relies on the shared app shell and skips
  // its Speculative prefetch. Propagates upward so the root reflects the
  // entire subtree.
  SubtreeHasEagerPrefetch = 0b1000000000000,
  // This segment or one of its descendants exports `instant = false`,
  // explicitly opting out of Partial Prefetching. Propagates upward so the root
  // reflects the entire subtree. Used only to suppress the dev-time
  // `<Link prefetch={true}>` warning — unlike PrefetchDisabled, it has no effect
  // on the actual prefetch behavior.
  SubtreeHasInstantFalse = 0b10000000000000,
  // The client should attempt a static prefetch for this route: the
  // build-time prerender did not access any runtime data (cookies, headers,
  // searchParams, ...), so a static prefetch is expected to be as complete
  // as a runtime one. A fallback-param access only unsets the bit when the
  // route can never be upgraded from a fallback to a concrete prerender —
  // on an upgradeable route, ISR later produces the concrete prerender a
  // static attempt would hit (until then, the static responses' own
  // signal reports the insufficiency per response). Purely advisory, and
  // both error directions are safe: if set when a runtime request is
  // actually needed, that same response-level signal (the load-bearing
  // `needsRuntimeRequest` promise combined with each segment's `isPartial`)
  // directs the client to follow up — the cost is a wasted static attempt.
  // If unset when static would have sufficed, the client goes straight to a
  // runtime prefetch, which is a superset of the static response — the cost
  // is only reduced cacheability. Like the other bits, this one is computed
  // once per build and stays constant for the build's lifetime; it rides
  // the prefetch-hints manifest into every response that carries hints —
  // `/_tree` prefetch responses and the FlightRouterState of dynamic
  // navigations alike. (Routes missing from the manifest — see the #91407
  // fallbacks — simply never carry it.) Set on every node of the tree, but
  // does not propagate.
  ShouldAttemptStaticPrefetch = 0b100000000000000,
}

/**
 * Bitmask for checking whether a segment's static prefetch is skipped — i.e.
 * the server emits no static data for it (its slot in a segment bundle is
 * null, and it participates in the bundle chain only as a pass-through) and
 * the client never issues a static request for it.
 *
 * Static prefetching is disabled ONLY by `prefetch: 'force-disabled'`
 * (PrefetchDisabled). Notably, Partial Prefetching segments DO have static
 * data even though they require runtime completeness: the server emits it
 * unconditionally — it can't be gated on the ShouldAttemptStaticPrefetch
 * hint, because null-slot positions in segment bundles must be deterministic
 * from build-time config. A runtime request may still be needed for the
 * segment, but the scheduler may attempt a static prefetch first (per the
 * ShouldAttemptStaticPrefetch hint) and skip the runtime request if the
 * static response proves sufficient.
 *
 * Usage: `(hints & StaticPrefetchDisabled) !== 0`
 */
export const StaticPrefetchDisabled = PrefetchHint.PrefetchDisabled

/**
 * The subset of PrefetchHint bits that propagate upward from a child segment to
 * its ancestors (as opposed to segment-local bits like SegmentHasLoadingBoundary
 * or IsRootLayoutOrAbove). Used to clear stale propagated bits before re-deriving them
 * from a node's children.
 */
export const SubtreePrefetchHints =
  PrefetchHint.SubtreeHasPartialPrefetching |
  PrefetchHint.SubtreeHasLoadingBoundary |
  PrefetchHint.SubtreeHasInstantFalse |
  PrefetchHint.SubtreeHasEagerPrefetch

/**
 * Folds a child segment's prefetch hints into its parent's, propagating the
 * "subtree" flags. A child's segment-local flag (e.g. it has a loading
 * boundary) becomes the corresponding "subtree" flag on the parent, so the
 * root segment ends up reflecting the entire subtree.
 *
 * Used wherever a route tree is assembled bottom-up: on the server when building
 * a prefetch tree (createFlightRouterStateFromLoaderTree) and on the client when
 * merging a navigation patch into the existing tree (convertServerPatchToFullTree).
 * Keep these in sync by routing both through this helper.
 */
export function propagateSubtreeBits(
  parentHints: number,
  childHints: number
): number {
  if (childHints & PrefetchHint.SubtreeHasPartialPrefetching) {
    parentHints |= PrefetchHint.SubtreeHasPartialPrefetching
  }
  // A child with a loading boundary (directly, or anywhere in its subtree) makes
  // this a SubtreeHasLoadingBoundary on the parent.
  if (
    childHints &
    (PrefetchHint.SegmentHasLoadingBoundary |
      PrefetchHint.SubtreeHasLoadingBoundary)
  ) {
    parentHints |= PrefetchHint.SubtreeHasLoadingBoundary
  }
  // And for eager prefetch. The bit is set directly on each eager segment, so
  // there's no separate segment-local flag — propagate it as-is.
  if (childHints & PrefetchHint.SubtreeHasEagerPrefetch) {
    parentHints |= PrefetchHint.SubtreeHasEagerPrefetch
  }
  // And for `instant = false`. Like eager prefetch, the bit is set directly on
  // each opted-out segment, so propagate it as-is.
  if (childHints & PrefetchHint.SubtreeHasInstantFalse) {
    parentHints |= PrefetchHint.SubtreeHasInstantFalse
  }
  return parentHints
}

/**
 * Individual Flight response path
 */
export type FlightSegmentPath =
  // Uses `any` as repeating pattern can't be typed.
  | any[]
  // Looks somewhat like this
  | [
      segment: Segment,
      parallelRouterKey: string,
      segment: Segment,
      parallelRouterKey: string,
      segment: Segment,
      parallelRouterKey: string,
    ]

/**
 * Represents a tree of segments and the Flight data (i.e. React nodes) that
 * correspond to each one. The tree is isomorphic to the FlightRouterState;
 * however in the future we want to be able to fetch arbitrary partial segments
 * without having to fetch all its children. So this response format will
 * likely change.
 */
export type CacheNodeSeedData = [
  node: React.ReactNode | null,
  parallelRoutes: {
    [parallelRouterKey: string]: CacheNodeSeedData | null
  },
  // TODO: This field is no longer used. Remove it.
  loading: null,
  isPartial: boolean,
  /**
   * An AsyncIterable that yields the route params this segment accessed during
   * server rendering (one name per yield, deduped). Used by the client router
   * to determine cache key specificity - segments that only access certain
   * params can be reused across navigations where unaccessed params change.
   *
   * Does NOT include root params; those are emitted once at the top level of
   * the response (see `r` on the payload) and unioned in by the consumer.
   *
   * - null: tracking was not enabled for this render (e.g., not a prerender).
   *   Treat conservatively - assume all params vary.
   * - Drains to empty Set: segment accesses no params (e.g., client components,
   *   or server components that don't read params). Can be shared across all
   *   param values.
   * - Drains to non-empty Set: segment depends on those params. Can only reuse
   *   when those specific params match.
   */
  varyParams: VaryParamsIterable | null,
]

export type FlightDataSegment = [
  /* segment of the rendered slice: */ Segment,
  /* treePatch */ FlightRouterState,
  /* cacheNodeSeedData */ CacheNodeSeedData | null, // Can be null during prefetch if there's no loading component
  /* head: viewport */ HeadData,
  /* isHeadPartial */ boolean,
]

export type FlightDataPath =
  // Uses `any` as repeating pattern can't be typed.
  | any[]
  // Looks somewhat like this
  | [
      // Holds full path to the segment.
      ...FlightSegmentPath[],
      ...FlightDataSegment,
    ]

/**
 * The Flight response data
 */
export type FlightData = Array<FlightDataPath> | string

/**
 * Per-route prefetch hints computed at build time. Mirrors the shape of the
 * loader tree so hints can be traversed in parallel during router state
 * creation. Each node stores a bitmask of PrefetchHint flags
 * (ParentInlinedIntoSelf, InlinedIntoChild) computed by the segment size
 * measurement pass.
 *
 * Persisted to prefetch-hints.json as Record<string, PrefetchHints> (keyed
 * by route pattern) and loaded at server startup.
 */
export type PrefetchHints = {
  /** Bitmask of PrefetchHint flags for this segment. */
  hints: number
  /** Child hint nodes, keyed by parallel route key. */
  slots: Record<string, PrefetchHints> | null
}

export type ActionResult = Promise<any>

export type InitialRSCPayload = {
  /** buildId, can be empty if the x-nextjs-build-id header is set */
  b?: string
  /** initialCanonicalUrlParts */
  c: string[]
  /** initialRenderedSearch */
  q: string
  /** couldBeIntercepted */
  i: boolean
  /** initialFlightData */
  f: FlightDataPath[]
  /** missingSlots */
  m: Set<string> | undefined
  /** GlobalError */
  G: [React.ComponentType<any>, React.ReactNode | undefined]
  /** supportsPerSegmentPrefetching */
  S: boolean
  /**
   * headVaryParams - vary params for the head (metadata) of the response.
   * Does not include root params (see `r`).
   */
  h: VaryParamsIterable | null
  /**
   * rootVaryParams - the root params accessed anywhere in the response, emitted
   * once. The client unions these into the head and every segment's vary
   * params, rather than the server folding them into each set.
   */
  r?: VaryParamsIterable
  /** staleTime in seconds - Only present when Cache Components is enabled. */
  s?: AsyncIterable<number>
  /**
   * runtimeDataAccessed — whether the render has accessed a data source that
   * hangs during a static prerender but would resolve during a runtime
   * prerender (cookies, headers, fallback params, searchParams, ...). The
   * flag is monotonic (false → true, at most once), so it's encoded as a
   * promise: resolved `true` at the moment of first access — the fulfillment
   * row's position in the stream records the stage the access happened in —
   * or resolved `false` when the prerender completes without one, a row that
   * lands past every stage boundary. A truncated (shell) decode therefore
   * reads the answer as of the shell stage: fulfilled `true` iff the access
   * happened during a stage it includes, pending (⇒ no access) otherwise.
   * Unlike an async iterable, a pending promise costs Flight no abort
   * listener on the render. Used when generating per-segment prefetch
   * responses (forwarded as the response-level `needsRuntimeRequest`).
   * The build-constant `PrefetchHint.ShouldAttemptStaticPrefetch` is
   * tracked directly on the prerender store instead (its
   * `shouldAttemptStaticPrefetch` cell) — it needs neither stream
   * positioning nor this flag's param/non-param blindness. Only present
   * for static prerenders when Cache Components is enabled.
   */
  u?: Promise<boolean>
  /** staticStageByteLength - Resolves when the static stage ends. */
  l?: Promise<number>
  /**
   * shellByteLength - Resolves when the shell stage ends.
   * If it resolves to null, then the shell is the same as the main response.
   * */
  a?: Promise<number | null>
  /** runtimePrefetchStream — Embedded runtime prefetch Flight stream. */
  p?: ReadableStream<Uint8Array>
  /**
   * dynamicStaleTime — Per-page BFCache stale time in seconds, from
   * `unstable_dynamicStaleTime`. Only included for dynamic renders. Controls
   * how long the client router cache retains dynamic navigation data. This is
   * distinct from the `s` field, which controls segment cache (prefetch)
   * staleness.
   */
  d?: number
  /**
   * revealAfter (dev only). Resolves once the server has flushed the
   * shell-stage content to the stream (static shell, or runtime-prefetchable
   * shell for runtime-prefetch routes), or earlier on a cache miss. The client
   * decodes this from the payload and defers resolving the response's deferred
   * RSCs on it, so a boundary's children aren't revealed before their row has
   * been decoded (which would flush a premature Suspense fallback). Its
   * resolution row follows the children's row in the payload, so the children
   * are decoded by the time the client unblocks. The HTML render gates on the
   * same signal server-side instead of reading this field.
   */
  _revealAfter?: Promise<void>
}

// Response from `createFromFetch` for normal rendering
export type NavigationFlightResponse = {
  /** buildId, can be empty if the x-nextjs-build-id header is set */
  b?: string
  /** flightData */
  f: FlightData
  /** supportsPerSegmentPrefetching */
  S: boolean
  /** renderedSearch */
  q: string
  /** couldBeIntercepted */
  i: boolean
  /** staleTime - Only present in dynamic runtime prefetch responses. */
  s?: AsyncIterable<number>
  /** staticStageByteLength - Resolves when the static stage ends. */
  l?: Promise<number>
  /**
   * shellByteLength - Resolves when the shell stage ends.
   * If it resolves to null, then the shell is the same as the main response.
   * */
  a?: Promise<number | null>
  /**
   * shellUsedSessionData - true if resolving session data
   * unblocked new content in the shell.
   * NOTE: only use this in runtime/session prefetch requests
   * where we have a proper session shell.
   * */
  u?: Promise<boolean>
  /** headVaryParams. Does not include root params (see `r`). */
  h: VaryParamsIterable | null
  /**
   * rootVaryParams - the root params accessed anywhere in the response, emitted
   * once. The client unions these into the head and every segment's vary
   * params.
   */
  r?: VaryParamsIterable
  /** runtimePrefetchStream — Embedded runtime prefetch Flight stream. */
  p?: ReadableStream<Uint8Array>
  /**
   * dynamicStaleTime — Per-page BFCache stale time in seconds, from
   * `unstable_dynamicStaleTime`. Only included for dynamic renders. Controls
   * how long the client router cache retains dynamic navigation data. This is
   * distinct from the `s` field, which controls segment cache (prefetch)
   * staleness.
   */
  d?: number
  /**
   * revealAfter (dev only). Resolves once the server has flushed the
   * shell-stage content to the stream (static shell, or runtime-prefetchable
   * shell for runtime-prefetch routes), or earlier on a cache miss. The client
   * decodes this from the payload and defers resolving the response's deferred
   * RSCs on it, so a boundary's children aren't revealed before their row has
   * been decoded (which would flush a premature Suspense fallback). Its
   * resolution row follows the children's row in the payload, so the children
   * are decoded by the time the client unblocks. The HTML render gates on the
   * same signal server-side instead of reading this field.
   */
  _revealAfter?: Promise<void>
}

// Response from `createFromFetch` for server actions. Action's flight data can be null
export type ActionFlightResponse = {
  /** actionResult */
  a: ActionResult
  /** buildId, can be empty if the x-nextjs-build-id header is set */
  b?: string
  /** flightData */
  f: FlightData
  /** renderedSearch */
  q: string
  /** couldBeIntercepted */
  i: boolean
}

export type RSCPayload =
  | InitialRSCPayload
  | NavigationFlightResponse
  | ActionFlightResponse

export type InstantCookie =
  // pending (waiting to capture)
  | [captured: 0, id: string]
  // captured MPA page load
  | [captured: 1, id: string, state: null]
  // captured SPA navigation (from/to route trees)
  | [
      captured: 1,
      id: string,
      state: { from: FlightRouterState; to: FlightRouterState | null },
    ]

import type { IncomingMessage, ServerResponse } from 'http'
import type { ParsedUrlQuery } from 'querystring'
import type { UrlWithParsedQuery } from 'url'
import type { BaseNextRequest } from './base-http'
import type { CloneableBody } from './body-streams'
import type { RouteMatch } from './route-matches/route-match'
import type { NEXT_RSC_UNION_QUERY } from '../client/components/app-router-headers'
import type {
  ResponseCacheEntry,
  ServerComponentsHmrCache,
} from './response-cache'
import type { PagesDevOverlayBridgeType } from '../next-devtools/userspace/pages/pages-dev-overlay-setup'
import type { OpaqueFallbackRouteParams } from './request/fallback-params'
import type { IncrementalCache } from './lib/incremental-cache'
import type { RevalidateFn } from './lib/router-utils/router-server-context'
import type { NextRequest } from './web/exports'

// FIXME: (wyattjoh) this is a temporary solution to allow us to pass data between bundled modules
export const NEXT_REQUEST_META = Symbol.for('NextInternalRequestMeta')

export type NextIncomingMessage = (
  | BaseNextRequest
  | IncomingMessage
  | NextRequest
) & {
  [NEXT_REQUEST_META]?: RequestMeta
}

/**
 * The callback function to call when a response cache entry was generated or
 * looked up in the cache. When it returns true, the server assumes that the
 * handler has already responded to the request and will not do so itself.
 */
export type OnCacheEntryHandler = (
  /**
   * The response cache entry that was generated or looked up in the cache.
   */
  cacheEntry: ResponseCacheEntry,

  /**
   * The request metadata.
   */
  requestMeta: {
    /**
     * The URL that was used to make the request.
     */
    url: string | undefined
  }
) => Promise<boolean | void> | boolean | void

export interface RequestMeta {
  /**
   * The query that was used to make the request.
   */
  initQuery?: ParsedUrlQuery

  /**
   * The URL that was used to make the request.
   */
  initURL?: string

  /**
   * The protocol that was used to make the request.
   */
  initProtocol?: string

  /**
   * The body that was read from the request. This is used to allow the body to
   * be read multiple times.
   */
  clonableBody?: CloneableBody

  /**
   * True when the request matched a locale domain that was configured in the
   * next.config.js file.
   */
  isLocaleDomain?: boolean

  /**
   * True when the request had locale information stripped from the pathname
   * part of the URL.
   */
  didStripLocale?: boolean

  /**
   * If the request had its URL rewritten, this is the pathname it was rewritten
   * to (not a full URL, just the pathname).
   */
  rewrittenPathname?: string

  /**
   * The cookies that were added by middleware and were added to the response.
   */
  middlewareCookie?: string[]

  /**
   * The match on the request for a given route.
   */
  match?: RouteMatch

  /**
   * The incremental cache to use for the request.
   */
  incrementalCache?: IncrementalCache

  /**
   * The server components HMR cache, only for dev.
   */
  serverComponentsHmrCache?: ServerComponentsHmrCache

  /**
   * The hash of the most recent server component change (dev only), set by the
   * router-server from the hot-reloader. Included in `"use cache"` cache keys
   * so that cached entries are revalidated after an edit, for every client,
   * regardless of whether it runs the HMR client.
   */
  hmrRefreshHash?: string

  /** Client HMR version captured before rendering dev-server HTML. */
  initialHmrVersion?: string

  /**
   * Equals the segment path that was used for the prefetch RSC request.
   */
  segmentPrefetchRSCRequest?: string

  /**
   * True when the request is for the prefetch flight data.
   */
  isPrefetchRSCRequest?: true

  /**
   * True when the request is for the flight data.
   */
  isRSCRequest?: true

  /**
   * A search param set by the Next.js client when performing RSC requests.
   * Because some CDNs do not vary their cache entries on our custom headers,
   * this search param represents a hash of the header values. For any cached
   * RSC request, we should verify that the hash matches before responding.
   * Otherwise this can lead to cache poisoning.
   * TODO: Consider not using custom request headers at all, and instead encode
   * everything into the search param.
   */
  cacheBustingSearchParam?: string

  /**
   * True when the request is for the `/_next/data` route using the pages
   * router.
   */
  isNextDataReq?: true

  /**
   * Postponed state to use for resumption. When absent, the request is not a
   * resume request. A non-empty string contains the state to resume, while an
   * empty string represents a resume request without postponed state and
   * signals that the renderer should perform a full dynamic render.
   *
   * There are no guarantees that the page actually postponed, as verifying
   * that would incur an additional cache lookup.
   */
  postponed?: string

  /**
   * The action body extracted from a server action request when the postponed
   * state was prepended to the body by the proxy. This allows the action
   * handler to read the action payload without re-reading the consumed stream.
   */
  actionBody?: Buffer

  /**
   * If provided, this will be called when a response cache entry was generated
   * or looked up in the cache.
   *
   * @deprecated Use `onCacheEntryV2` instead.
   */
  onCacheEntry?: OnCacheEntryHandler

  /**
   * If provided, this will be called when a response cache entry was generated
   * or looked up in the cache.
   */
  onCacheEntryV2?: OnCacheEntryHandler

  /**
   * The previous revalidate before rendering 404 page for notFound: true
   */
  notFoundRevalidate?: number | false

  /**
   * In development, the original source page that returned a 404.
   */
  developmentNotFoundSourcePage?: string

  /**
   * The path we routed to and should be invoked
   */
  invokePath?: string

  /**
   * The specific page output we should be matching
   */
  invokeOutput?: string

  /**
   * The status we are invoking the request with from routing
   */
  invokeStatus?: number

  /**
   * The routing error we are invoking with
   */
  invokeError?: Error

  /**
   * The query parsed for the invocation
   */
  invokeQuery?: Record<string, undefined | string | string[]>

  /**
   * Whether the request is a middleware invocation
   */
  middlewareInvoke?: boolean

  /**
   * The W3C `traceparent` of the middleware invocation's `handleRequest` span,
   * written onto the request headers so the middleware span and the render
   * that follows are siblings under that span.
   */
  middlewareInvokeTraceparent?: string

  /**
   * Whether the request should render the fallback shell or not.
   */
  renderFallbackShell?: boolean

  /**
   * Route param keys that were explicitly resolved from partial nxtP*
   * query params during background revalidation. Used by app-page.ts to
   * determine which fallback params should remain deferred vs resolved
   * in intermediate PPR shells.
   */
  resolvedRouteParamKeys?: Set<string>

  /**
   * Whether the request is for the custom error page.
   */
  customErrorRender?: true

  /**
   * Whether to bubble up the NoFallbackError to the caller when a 404 is
   * returned.
   */
  bubbleNoFallback?: true

  /**
   * True when the request had locale information inferred from the default
   * locale.
   */
  localeInferredFromDefault?: true

  /**
   * The locale that was inferred or explicitly set for the request.
   */
  locale?: string

  /**
   * The default locale that was inferred or explicitly set for the request.
   */
  defaultLocale?: string

  /**
   * The relative project dir the server is running in from project root
   */
  relativeProjectDir?: string

  /**
   * The dist directory the server is currently using
   */
  distDir?: string

  /**
    Optional hostname used by route handlers when constructing absolute URLs.
    hostname: '127.0.0.1',
   */
  hostname?: string

  /**
   Optional internal revalidate function to avoid revalidating over the network
   */
  revalidate?: RevalidateFn

  /**
   Optional function to render the 404 page for pages router `notFound: true`
   */
  render404?: (
    req: IncomingMessage,
    res: ServerResponse,
    parsedUrl?: UrlWithParsedQuery,
    setHeaders?: boolean
  ) => Promise<void>

  /**
   * The query after resolving routes
   */
  query?: ParsedUrlQuery

  /**
   * The params after resolving routes
   */
  params?: ParsedUrlQuery

  /**
   * ErrorOverlay component to use in development for pages router
   */
  PagesErrorDebug?: PagesDevOverlayBridgeType

  /**
   * Whether server is in minimal mode (this will be replaced with more
   * specific flags in future)
   */
  minimalMode?: boolean

  /**
   * Staged renders defer these route params until after the static stage. They
   * keep their concrete request values instead of replacing them with
   * placeholders. Dev static-shell validation uses the same set for the
   * selected shell.
   *
   * For `/t2/items/b2` with selected shell `/t2/items/[bottom]`, this map
   * contains only `bottom`:
   * - A layout's `params` containing only `top` can resolve statically.
   * - A page's `params` containing `bottom` waits until after the static stage.
   *
   * A set recorded in postponed state overrides this metadata on a resume,
   * including an explicitly empty set.
   */
  stagedFallbackParams?: OpaqueFallbackRouteParams | null

  /**
   * Dev static-shell debug renders use these params to prerender the matched
   * source shell. The Instant Navigation Testing API uses this path too. The
   * prerender substitutes opaque placeholders for these params rather than
   * using their request values.
   *
   * Suppose `generateStaticParams` returns `[{ top: 't1' }]` for
   * `/[top]/items/[bottom]`. A request for `/t2/items/b2` has:
   * - Source `/[top]/items/[bottom]`: `top` and `bottom` are unresolved.
   * - Completed shell `/t2/items/[bottom]`: only `bottom` is unresolved.
   *
   * This map contains the source's `top` and `bottom`. A debug render of that
   * source also uses this map as `stagedFallbackParams`.
   */
  fallbackRouteParams?: OpaqueFallbackRouteParams | null

  /** DEV only: parameter matching rejected this request as not found. */
  devParamMatchingRejected?: boolean

  /** DEV only: closed parameters, including for successful allowed values. */
  devNotFoundParams?: readonly string[]

  /**
   * DEV only: Request timings in process.hrtime.bigint()
   */
  devRequestTimingStart?: bigint
  devRequestTimingMiddlewareStart?: bigint
  devRequestTimingMiddlewareEnd?: bigint
  devRequestTimingInternalsEnd?: bigint

  /**
   * DEV only: The duration of getStaticPaths/generateStaticParams in process.hrtime.bigint()
   */
  devGenerateStaticParamsDuration?: bigint

  /**
   * DEV only: Server action log info to be logged after the request log
   */
  devServerActionLog?: {
    functionName: string
    args: unknown[]
    location: string
    duration: number
  }
}

/**
 * Gets the request metadata. If no key is provided, the entire metadata object
 * is returned.
 *
 * @param req the request to get the metadata from
 * @param key the key to get from the metadata (optional)
 * @returns the value for the key or the entire metadata object
 */
export function getRequestMeta(
  req: NextIncomingMessage,
  key?: undefined
): RequestMeta
export function getRequestMeta<K extends keyof RequestMeta>(
  req: NextIncomingMessage,
  key: K
): RequestMeta[K]
export function getRequestMeta<K extends keyof RequestMeta>(
  req: NextIncomingMessage,
  key?: K
): RequestMeta | RequestMeta[K] {
  const meta = req[NEXT_REQUEST_META] || {}
  return typeof key === 'string' ? meta[key] : meta
}

/**
 * Sets the request metadata.
 *
 * @param req the request to set the metadata on
 * @param meta the metadata to set
 * @returns the mutated request metadata
 */
export function setRequestMeta(req: NextIncomingMessage, meta: RequestMeta) {
  req[NEXT_REQUEST_META] = meta
  return meta
}

/**
 * Adds a value to the request metadata.
 *
 * @param request the request to mutate
 * @param key the key to set
 * @param value the value to set
 * @returns the mutated request metadata
 */
export function addRequestMeta<K extends keyof RequestMeta>(
  request: NextIncomingMessage,
  key: K,
  value: RequestMeta[K]
) {
  const meta = getRequestMeta(request)
  meta[key] = value
  return setRequestMeta(request, meta)
}

/**
 * Removes a key from the request metadata.
 *
 * @param request the request to mutate
 * @param key the key to remove
 * @returns the mutated request metadata
 */
export function removeRequestMeta<K extends keyof RequestMeta>(
  request: NextIncomingMessage,
  key: K
) {
  const meta = getRequestMeta(request)
  delete meta[key]
  return setRequestMeta(request, meta)
}

type NextQueryMetadata = {
  /**
   * The `_rsc` query parameter used for cache busting to ensure that the RSC
   * requests do not get cached by the browser explicitly.
   */
  [NEXT_RSC_UNION_QUERY]?: string
}

export type NextParsedUrlQuery = ParsedUrlQuery & NextQueryMetadata

/**
 * subset of `url.parse` return value
 */
interface LegacyUrl {
  auth?: string | null
  hash: string | null
  hostname: string | null
  href: string
  pathname: string | null
  protocol: string | null
  search: string | null
  slashes: boolean | null
  port: string | null
  query: string | null | ParsedUrlQuery
}
interface LegacyUrlWithParsedQuery extends LegacyUrl {
  query: ParsedUrlQuery
}

// TODO: Remove in favor of WHATWG URLs
export interface NextUrlWithParsedQuery extends LegacyUrlWithParsedQuery {
  query: NextParsedUrlQuery
}

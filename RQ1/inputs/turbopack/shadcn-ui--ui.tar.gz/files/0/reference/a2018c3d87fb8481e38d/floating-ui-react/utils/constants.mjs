export const FOCUSABLE_ATTRIBUTE = 'data-base-ui-focusable';
export const ACTIVE_KEY = 'active';
export const SELECTED_KEY = 'selected';
export const TYPEABLE_SELECTOR = "input:not([type='hidden']):not([disabled])," + "[contenteditable]:not([contenteditable='false']),textarea:not([disabled])";
export const ARROW_LEFT = 'ArrowLeft';
export const ARROW_RIGHT = 'ArrowRight';
export const ARROW_UP = 'ArrowUp';
export const ARROW_DOWN = 'ArrowDown';
module.exports = function () { /* empty */ };
